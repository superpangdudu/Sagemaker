import boto3
import sagemaker

import uuid
import time
import threading

from sagemaker.pytorch.model import PyTorchModel
from sagemaker.async_inference import AsyncInferenceConfig
from sagemaker.serializers import JSONSerializer
from sagemaker.deserializers import JSONDeserializer

#########################################################################################
ACCESS_KEY_ID = 'AKIAUHC5UZEKGAES5SEE'
ACCESS_KEY_SECRET = '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'
REGION = 'us-east-2'

INSTANCE_TYPE = 'ml.g4dn.2xlarge'
PYTHON_VERSION = 'py38'

MIN_ENDPOINT_CAPACITY = 1
MAX_ENDPOINT_CAPACITY = 8

models = [
    ('OIL-PAINTING-V8', './code')
]

#########################################################################################
boto3_session = boto3.session.Session(
    aws_access_key_id=ACCESS_KEY_ID,
    aws_secret_access_key=ACCESS_KEY_SECRET,
    region_name=REGION
)

cloudwatch_client = boto3_session.client('cloudwatch')
autoscaling_client = boto3_session.client('application-autoscaling')

# print(boto3_session.get_available_services())

sagemaker_session = sagemaker.Session(
    boto_session=boto3_session
)

s3 = boto3_session.resource('s3')
bucket = sagemaker_session.default_bucket()
print(f'bucket = {bucket}')

# role = sagemaker.get_execution_role(sagemaker_session)
role = 'arn:aws:iam::290106689812:role/KrlyMgr'
print(f'role = {role}')

#########################################################################################
# TODO Blow config is useless
model_name = 'sakistriker/AbyssOrangeMix3'
lora_model = 's3://sagemaker-us-east-1-596030579944/fakemonPokMonLORA/fakemonPokMonLORA_v10Beta.safetensors'

framework_version = '1.10'
py_version = 'py38'

model_environment = {
    'SAGEMAKER_MODEL_SERVER_TIMEOUT': '600',
    'SAGEMAKER_MODEL_SERVER_WORKERS': '1',
    'model_name': model_name,
    'lora_model': lora_model,
    's3_bucket': bucket
}

#########################################################################################
model_path = 's3://sagemaker-us-east-2-290106689812/stablediffusion/assets/model.tar.gz'


#########################################################################################
def deploy_model(name, source_dir):
    model = PyTorchModel(
        sagemaker_session=sagemaker_session,
        name=None,
        model_data=model_path,
        entry_point='inference.py',
        source_dir=source_dir,
        role=role,
        framework_version=framework_version,
        py_version=py_version,
        env=model_environment
    )

    #
    endpoint_name = f'{name}-{str(uuid.uuid4())}'
    async_config = AsyncInferenceConfig(output_path='s3://{0}/{1}/asyncinvoke/out/'.format(bucket, 'stablediffusion'))
    instance_count = 1

    #
    start_time = time.time()
    print(f'start to deploy model: {name}')
    async_predictor = model.deploy(
        endpoint_name=endpoint_name,
        instance_type=INSTANCE_TYPE,
        initial_instance_count=instance_count,
        async_inference_config=async_config,
        serializer=JSONSerializer(),
        deserializer=JSONDeserializer(),
        # wait=False
    )
    end_time = time.time()
    print(f'\nmodel {name} is deployed on {endpoint_name}, used {end_time - start_time}s')

    return async_predictor


def make_endpoint_scalable(endpoint_name, min_capacity, max_capacity):
    resource_id = f"endpoint/{endpoint_name}/variant/AllTraffic"

    # Configure Autoscaling on asynchronous endpoint down to zero instances
    response = autoscaling_client.register_scalable_target(
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        MinCapacity=min_capacity,
        MaxCapacity=max_capacity,
    )

    response = autoscaling_client.put_scaling_policy(
        PolicyName=f'Request-ScalingPolicy-{endpoint_name}',
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        PolicyType="TargetTrackingScaling",
        TargetTrackingScalingPolicyConfiguration={
            "TargetValue": 2.0,
            "CustomizedMetricSpecification": {
                "MetricName": "ApproximateBacklogSizePerInstance",
                "Namespace": "AWS/SageMaker",
                "Dimensions": [{"Name": "EndpointName", "Value": endpoint_name}],
                "Statistic": "Average",
            },
            "ScaleInCooldown": 600,  # duration until scale in begins (down to zero)
            "ScaleOutCooldown": 300  # duration between scale out attempts
        },
    )

    # response = autoscaling_client.put_scaling_policy(
    #     PolicyName="HasBacklogWithoutCapacity-ScalingPolicy",
    #     ServiceNamespace="sagemaker",
    #     ResourceId=resource_id,
    #     ScalableDimension="sagemaker:variant:DesiredInstanceCount",
    #     PolicyType="StepScaling",
    #     StepScalingPolicyConfiguration={
    #         "AdjustmentType": "ChangeInCapacity",
    #         "MetricAggregationType": "Average",
    #         "Cooldown": 300,
    #         "StepAdjustments": [
    #             {
    #                 "MetricIntervalLowerBound": 0,
    #                 "ScalingAdjustment": 1
    #             }
    #         ]
    #     },
    # )
    #
    # response = cloudwatch_client.put_metric_alarm(
    #     AlarmName='HasBacklogWithoutCapacity',
    #     MetricName='HasBacklogWithoutCapacity',
    #     ActionsEnabled=True,
    #     Namespace='AWS/SageMaker',
    #     Statistic='Average',
    #     EvaluationPeriods=2,
    #     DatapointsToAlarm=2,
    #     Threshold=1,
    #     ComparisonOperator='GreaterThanOrEqualToThreshold',
    #     TreatMissingData='missing',
    #     Dimensions=[
    #         {'Name': 'EndpointName', 'Value': endpoint_name},
    #     ],
    #     Period=60
    # )


#########################################################################################
def test_predict(predictor):
    from sagemaker.async_inference.waiter_config import WaiterConfig

    inputs_txt2img = {
        "prompt": "oilpainting\(style\), oil painting \(medium\), masterpiece, paintbrush, a painting of ",
        "negative_prompt": "worst quality, blurry, nsfw, zombie, blush, rough, ugly, distort, poorly drawn face, poor facial details, poorly drawn hands, poorly rendered hands, poorly drawn face, poorly drawn eyes, poorly drawn nose, poorly drawn mouth, poorly Rendered face, disfigured, deformed body features, bad proportions, extra limbs, cloned face, disfigured, gross proportions, malformed limbs, missing arms, missing legs, extra arms, extra legs, fused fingers, too many fingers, long neck, username, watermark, signature, ",
        "steps": 20,
        "sampler": "dpm2_a",
        "seed": 52362,
        "height": 1080,
        "width": 720,
        "count": 2,
        "input_image": 's3://sagemaker-us-east-2-290106689812/image/test_oilpainting.jpg'
    }

    response = predictor.predict_async(inputs_txt2img)

    print(f"Response object: {response}")
    print(f"Response output path: {response.output_path}")
    print("Start Polling to get response:")

    start = time.time()
    config = WaiterConfig(
        max_attempts=100,  # number of attempts
        delay=10  # time in seconds to wait between attempts
    )

    result = response.get_result(config)
    print(f'{result}')
    print(f"Time taken: {time.time() - start}s")


#########################################################################################
predictors = []


def do_model_deploying(name, src):
    predictor = deploy_model(name, src)
    predictors.append(predictor)
    # make_endpoint_scalable(predictor.endpoint_name, MIN_ENDPOINT_CAPACITY, MAX_ENDPOINT_CAPACITY)
    test_predict(predictor)


threads = []
for (n, s) in models:
    thread = threading.Thread(target=do_model_deploying, args=(n, s))
    thread.start()
    threads.append(thread)

for t in threads:
    t.join()

# for p in predictors:
#     p.delete_endpoint()
# async_predictor.delete_endpoint()
